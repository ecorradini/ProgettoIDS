Nella cartella di progetto abbiamo:

- GetOut!.apk
- Relazione_Finale.pdf
- Server.tar -> inserito per sicurezza nel caso in cui lo script
		per l' installazione del Server non funzionasse

e 3 sottocartelle

- Manuali: tutti i manuali e una sottocartella
	-Scripts: per sicurezza sono riportati i vari file .sh nel caso in 
		  cui lo scaricamento automatico dal web attraverso le 
		  istruzioni riportate sui manuali fallisca
- SRC: codici sorgenti zippati
- Diagrammi: con due ulteriori sottocartelle
	- Dialogue & Navigation: relativi a tutto il progetto
	- User stories: con le varie user stories come cartelle numerate
			e dentro le stesse tutto il materiale di ciascuna


